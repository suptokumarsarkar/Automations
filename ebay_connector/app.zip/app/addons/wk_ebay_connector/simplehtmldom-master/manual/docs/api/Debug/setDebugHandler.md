---
title: setDebugHandler()
---

```php
Debug::setDebugHandler ( [$function = null] )
```

Sets the debug handler for debug messages. Uses `error_log` if `$function = null` (default).