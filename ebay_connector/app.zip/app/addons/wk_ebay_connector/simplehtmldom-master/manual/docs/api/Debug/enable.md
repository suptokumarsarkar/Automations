---
title: enable()
---

```php
Debug::enable ()
```

Globally enables debug messages.