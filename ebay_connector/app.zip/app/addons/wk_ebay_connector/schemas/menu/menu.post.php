<?php


 $schema['central']['website']['items']['ebay'] = array(
     'attrs' => array(
         'class'=>'is-addon'
     ),
     'href' => 'wk_ebay.manage',
	 'description'=>'ebay.description',
     'position' => 150,
     
 );

 
 return $schema;
